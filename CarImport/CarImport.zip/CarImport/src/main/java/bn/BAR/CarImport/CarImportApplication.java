package bn.BAR.CarImport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarImportApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarImportApplication.class, args);
	}

}
